# Fractured Survival Web (Starter)

A minimal, **mobile-friendly** Next.js 14 + Prisma + NextAuth starter with forums.

## 1) Environment

Copy `.env.example` to `.env.local` (or set vars on Vercel):

```
DATABASE_URL=postgresql://USER:PASS@HOST:PORT/DB?sslmode=require
NEXTAUTH_URL=https://your-vercel-url.vercel.app
NEXTAUTH_SECRET=your-32-byte-secret
```

## 2) First run

```
npm i --legacy-peer-deps
npx prisma db push
npm run seed
npm run dev
```

## 3) Deploy to Vercel

- Add the same env vars in Vercel → Project → Settings → Environment Variables
- Redeploy

## 4) Accounts

- Register at `/register`
- Login at `/login`

## 5) Forums

- Visit `/forums` to see categories
- Go to `/forums/[slug]` and click **Start a new thread** (requires login)
- View threads at `/forums/thread/[id]` and reply

## Notes

- Uses **Credentials** provider only (email/password with bcrypt)
- No Tailwind to keep it lightweight
- Basic CSS in `globals.css`
