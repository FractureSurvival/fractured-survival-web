import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

async function main() {
  const defaults = [
    { name: "News & Announcements", slug: "news" },
    { name: "General Discussion", slug: "general" },
    { name: "Help & Support", slug: "help" },
  ];
  for (const c of defaults) {
    await prisma.category.upsert({
      where: { slug: c.slug },
      create: c,
      update: {},
    });
  }
  console.log("Seeded default categories.");
}
main().then(() => prisma.$disconnect()).catch(async (e) => {
  console.error(e);
  await prisma.$disconnect();
  process.exit(1);
});
