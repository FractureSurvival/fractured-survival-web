export default function HomePage() {
  return (
    <section className="card">
      <h1>Fractured Survival</h1>
      <p>Welcome. Use the navigation to register, log in, and post in the forums.</p>
    </section>
  );
}
