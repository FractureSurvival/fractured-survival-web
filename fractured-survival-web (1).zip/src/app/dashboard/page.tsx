import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";
import Link from "next/link";

export const dynamic = "force-dynamic";

export default async function Dashboard() {
  const session = await getServerSession(authOptions);
  if (!session?.user) {
    return (
      <div className="card">
        <h1>Dashboard</h1>
        <p>Please <Link href="/login">log in</Link> to continue.</p>
      </div>
    );
  }
  return (
    <div className="card">
      <h1>Welcome, {session.user.name ?? session.user.email}</h1>
      <p>Jump into the <Link href="/forums">forums</Link>.</p>
    </div>
  );
}
