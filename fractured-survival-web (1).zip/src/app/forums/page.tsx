import Link from "next/link";
import { prisma } from "@/lib/db";

export default async function ForumsHome() {
  const categories = await prisma.category.findMany({ orderBy: { name: "asc" } });
  return (
    <div className="card">
      <h1>Forums</h1>
      <ul>
        {categories.map(c => (
          <li key={c.id}>
            <Link href={`/forums/${c.slug}`}>{c.name}</Link>
          </li>
        ))}
      </ul>
    </div>
  );
}
