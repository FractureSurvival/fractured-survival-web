"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";

export default function NewThread({ params }: { params: { slug: string } }) {
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const router = useRouter();

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    const res = await fetch("/api/forum/create-thread", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ slug: params.slug, title, body })
    });
    const data = await res.json();
    if (!res.ok) setMsg(data.error || "Failed");
    else router.push(`/forums/thread/${data.id}`);
  }

  return (
    <div className="card" style={{ maxWidth: 720, margin: "0 auto" }}>
      <h1>New thread</h1>
      {msg && <p className="muted">{msg}</p>}
      <form onSubmit={onSubmit}>
        <div style={{ marginBottom: 12 }}>
          <label>Title</label>
          <input className="input" value={title} onChange={(e) => setTitle(e.target.value)} required />
        </div>
        <div style={{ marginBottom: 12 }}>
          <label>Body</label>
          <textarea className="input" rows={8} value={body} onChange={(e) => setBody(e.target.value)} required />
        </div>
        <button className="button" type="submit">Create</button>
      </form>
    </div>
  );
}
