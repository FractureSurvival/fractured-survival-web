import Link from "next/link";
import { prisma } from "@/lib/db";

export default async function CategoryPage({ params }: { params: { slug: string } }) {
  const category = await prisma.category.findUnique({ where: { slug: params.slug } });
  if (!category) return <div className="card"><h1>Not found</h1></div>;

  const threads = await prisma.thread.findMany({
    where: { categoryId: category.id },
    include: { author: true },
    orderBy: { createdAt: "desc" }
  });

  return (
    <div className="card">
      <h1>{category.name}</h1>
      <p><Link href={`/forums/${category.slug}/new`}>Start a new thread</Link></p>
      <ul>
        {threads.map(t => (
          <li key={t.id}>
            <Link href={`/forums/thread/${t.id}`}>{t.title}</Link>
            <span className="muted"> — by {t.author?.name ?? t.author?.email}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}
