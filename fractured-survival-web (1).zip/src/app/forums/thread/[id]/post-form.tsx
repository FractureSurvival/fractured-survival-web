"use client";

import { useState } from "react";

export default function NewPostForm({ threadId }: { threadId: number }) {
  const [body, setBody] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setMsg(null);
    const res = await fetch("/api/forum/create-post", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ threadId, body })
    });
    const data = await res.json();
    if (!res.ok) setMsg(data.error || "Failed");
    else {
      setBody("");
      window.location.reload();
    }
  }

  return (
    <form onSubmit={onSubmit}>
      {msg && <p className="muted">{msg}</p>}
      <textarea className="input" rows={5} value={body} onChange={(e) => setBody(e.target.value)} required />
      <div style={{ marginTop: 8 }}>
        <button className="button" type="submit">Reply</button>
      </div>
    </form>
  );
}
