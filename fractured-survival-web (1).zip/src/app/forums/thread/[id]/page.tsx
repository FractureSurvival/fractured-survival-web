import { prisma } from "@/lib/db";
import NewPostForm from "./post-form";

export default async function ThreadPage({ params }: { params: { id: string } }) {
  const threadId = Number(params.id);
  const thread = await prisma.thread.findUnique({
    where: { id: threadId },
    include: {
      author: true,
      posts: { include: { author: true }, orderBy: { createdAt: "asc" } }
    }
  });
  if (!thread) return <div className="card"><h1>Not found</h1></div>;

  return (
    <div className="card">
      <h1>{thread.title}</h1>
      <p className="muted">by {thread.author?.name ?? thread.author?.email} • {thread.createdAt.toLocaleString()}</p>
      <article style={{ whiteSpace: "pre-wrap", marginTop: 12 }}>{thread.body}</article>

      <h3 style={{ marginTop: 24 }}>Replies</h3>
      <ul>
        {thread.posts.map(p => (
          <li key={p.id} className="card" style={{ marginTop: 8 }}>
            <p className="muted">by {p.author?.name ?? p.author?.email} • {p.createdAt.toLocaleString()}</p>
            <div style={{ whiteSpace: "pre-wrap" }}>{p.body}</div>
          </li>
        ))}
      </ul>

      <div style={{ marginTop: 16 }}>
        <NewPostForm threadId={thread.id} />
      </div>
    </div>
  );
}
