import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export async function POST(req: Request) {
  const session = await getServerSession(authOptions);
  if (!session?.user?.email) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });

  const { slug, title, body } = await req.json();
  if (!slug || !title || !body) return NextResponse.json({ error: "Missing fields" }, { status: 400 });

  const user = await prisma.user.findUnique({ where: { email: session.user.email } });
  const category = await prisma.category.findUnique({ where: { slug } });
  if (!user || !category) return NextResponse.json({ error: "Invalid category or user" }, { status: 400 });

  const thread = await prisma.thread.create({
    data: { title, body, authorId: user.id, categoryId: category.id }
  });
  return NextResponse.json({ ok: true, id: thread.id });
}
