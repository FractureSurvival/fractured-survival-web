import "./globals.css";
import Link from "next/link";
import { ReactNode } from "react";
import { getServerSession } from "next-auth";
import { authOptions } from "@/lib/auth";

export const metadata = { title: "Fractured Survival", description: "Forums + Auth starter" };

export default async function RootLayout({ children }: { children: ReactNode }) {
  const session = await getServerSession(authOptions);
  return (
    <html lang="en">
      <body>
        <header className="container">
          <nav className="nav">
            <Link href="/">Home</Link>
            <Link href="/forums">Forums</Link>
            <Link href="/dashboard">Dashboard</Link>
            {session?.user ? (
              <form action="/api/auth/signout" method="post" style={{ marginLeft: "auto" }}>
                <button className="button">Sign out</button>
              </form>
            ) : (
              <Link href="/login" style={{ marginLeft: "auto" }}>Login</Link>
            )}
          </nav>
        </header>
        <main className="container">{children}</main>
        <footer className="container muted">© {new Date().getFullYear()} Fractured Survival</footer>
      </body>
    </html>
  );
}
